package com.atr07.pregna.ui.fragments.education

import androidx.lifecycle.ViewModel

class EducationViewModel : ViewModel() {
}