package com.atr07.pregna.ui.fragments.dashboard

import androidx.lifecycle.ViewModel
import com.atr07.pregna.MainApplication

class DashboardViewModel : ViewModel() {

}