package com.atr07.pregna.ui.fragments.settings

import androidx.lifecycle.ViewModel

class SettingsViewModel : ViewModel() {
}