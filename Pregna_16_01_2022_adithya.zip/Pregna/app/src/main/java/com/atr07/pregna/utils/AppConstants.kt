package com.atr07.pregna.utils

/**
 * Created by Adithya T Raj.
 **/

const val APP_SPLASH_TIME_MILLI: Long = 3000
const val PASSWORD_MIN_LENGTH: Int = 4