package com.atr07.pregna.ui.fragments.music

import androidx.lifecycle.ViewModel

class MusicViewModel : ViewModel() {
}