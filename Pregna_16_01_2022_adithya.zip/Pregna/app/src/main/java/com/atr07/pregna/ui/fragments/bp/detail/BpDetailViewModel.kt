package com.atr07.pregna.ui.fragments.bp.detail

import androidx.lifecycle.ViewModel

class BpDetailViewModel : ViewModel() {
}