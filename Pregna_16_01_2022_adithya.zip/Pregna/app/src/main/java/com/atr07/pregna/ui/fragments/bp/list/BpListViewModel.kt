package com.atr07.pregna.ui.fragments.bp.list

import androidx.lifecycle.ViewModel

class BpListViewModel : ViewModel() {

}